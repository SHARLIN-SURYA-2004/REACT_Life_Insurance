package com.security.template.enums;

public enum Role {
    USER,
    ADMIN,
    DEV
}
