package com.security.template;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
