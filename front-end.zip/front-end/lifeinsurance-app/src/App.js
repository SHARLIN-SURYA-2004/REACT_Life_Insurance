import React from 'react';
import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import About from './Components/AboutUs';
import AdminLogin from './Components/Adminlogin';
import ClaimsManagement from './Components/ClaimsManagement';
import Contact from './Components/ContactUs';
import CustomerManagement from './Components/CustomerManagement';
import Dashboard from './Components/Dashboard';
import FinalExpense from './Components/FinalExpenseInsurance';
import FinalExpenseCondition from './Components/FinalExpenseCondition';
import GroupLife from './Components/GroupLifeInsurance';
import GroupLifeCondition from './Components/GroupLifeCondition';
import GuaranteedIssueLife from './Components/GuaranteedIssueLife';
import GuaranteedIssueLifeCondition from './Components/GuaranteedIssueLifeCondition';
import Home from './Components/Home';
import IndexedUniversalLife from './Components/IndexedUniversalLife';
import IndexedUniversalLifeCondition from './Components/IndexedUniversalLifeCondition';
import Login from './Components/Login';
import PaymentsBilling from './Components/PaymentsBilling';
import PolicyManagement from './Components/PolicyManagement';
import ProfileSettings from './Components/ProfileSettings';
import Register from './Components/Register';
import ReportsAnalytics from './Components/ReportsAnalytics';
import Services from './Components/Services';
import Sidebar from './Components/Sidebar';
import SimplifiedIssueLife from './Components/SimplifiedIssueLife';
import SimplifiedIssueLifeCondition from './Components/SimplifiedIssueLifeCondition';
import TermLife from './Components/TermLife';
import TermLifeCondition from './Components/TermlifeCondition'
import UniversalLife from './Components/UniversalLife';
import UniversalLifeCondition from './Components/UniversalLifeCondition';
import VariableLife from './Components/VariableLife';
import VariableLifeCondition from './Components/VariableLifeCondition';
import VariableUniversalLife from './Components/VariableUniversalLife';
import VariableUniversalLifeCondition from './Components/VariableUniversalLifeCondition';
import WholeLife from './Components/WholeLife';
import WholeLifeCondition from './Components/WholeLifeCondition';
import Profile from './Components/Profile';
import Payment from './Components/Payment';
import Logout from './Components/Logout';

const App = () => {
  const [policies, setPolicies] = React.useState([]);
  const [customers, setCustomers] = React.useState([]);
  const [claims, setClaims] = React.useState([]);
  const [payments, setPayments] = React.useState([]);
  const [reports, setReports] = React.useState([]);


  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/termlife" element={<TermLife />} />
        <Route path="/termlifecondition" element={<TermLifeCondition />} />
        <Route path="/wholelife" element={<WholeLife />} />
        <Route path="/wholelifecondition" element={<WholeLifeCondition />} />
        <Route path="/universallife" element={<UniversalLife />} />
        <Route path="/universallifecondition" element={<UniversalLifeCondition />} />
        <Route path="/variablelife" element={<VariableLife />} />
        <Route path="/variablelifecondition" element={<VariableLifeCondition />} />
        <Route path="/variableuniversallife" element={<VariableUniversalLife />} />
        <Route path="/variableuniversallifecondition" element={<VariableUniversalLifeCondition />} />
        <Route path="/indexeduniversallife" element={<IndexedUniversalLife />} />
        <Route path="/indexeduniversallifecondition" element={<IndexedUniversalLifeCondition />} />
        <Route path="/guaranteedissuelife" element={<GuaranteedIssueLife />} />
        <Route path="/guaranteedissuelifecondition" element={<GuaranteedIssueLifeCondition />} />
        <Route path="/simplifiedissuelife" element={<SimplifiedIssueLife />} />
        <Route path="/simplifiedissuelifecondition" element={<SimplifiedIssueLifeCondition />} />
        <Route path="/grouplife" element={<GroupLife />} />
        <Route path="/grouplifecondition" element={<GroupLifeCondition />} />
        <Route path="/finalexpense" element={<FinalExpense />} />
        <Route path="/finalexpensecondition" element={<FinalExpenseCondition />} />
        <Route path="/adminlogin" element={<AdminLogin />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/sidebar" element={<Sidebar />} />
        <Route path="/profile-settings" element={<ProfileSettings />} />
        <Route path="/policy-management" element={<PolicyManagement policies={policies} setPolicies={setPolicies} />} />
        <Route path="/customer-management" element={<CustomerManagement customers={customers} setCustomers={setCustomers} />} />
        <Route path="/claims-management" element={<ClaimsManagement claims={claims} setClaims={setClaims} />} />
        <Route path="/payments-billing" element={<PaymentsBilling payments={payments} setPayments={setPayments} />} />
        <Route path="/reports-analytics" element={<ReportsAnalytics reports={reports} setReports={setReports} />} />
        <Route path="/payment" element={<Payment />} />
        <Route path='/logout' element={<Logout />}/>
    
      </Routes>
    </Router>
  );
};

export default App;
